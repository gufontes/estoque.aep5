document.addEventListener('DOMContentLoaded', function() {
    const productTableBody = document.getElementById('product-table-body');
    const productForm = document.getElementById('product-form');

    const products = [];

    function renderProducts() {
        productTableBody.innerHTML = '';
        products.forEach((product, index) => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${product.name}</td>
                <td>${product.purchasePrice}</td>
                <td>${product.expirationDate}</td>
                <td>${product.stock}</td>
                <td>${product.minStock}</td>
                <td><button class="action-btn" onclick="editProduct(${index})"><i class="fa fa-edit"></i></button></td>
                <td><button class="action-btn" onclick="removeProduct(${index})"><i class="fa fa-trash"></i></button></td>
            `;

            productTableBody.appendChild(row);
        });
    }

    window.showAllProducts = function() {
        productForm.classList.add('hidden');
        renderProducts();
    }

    window.showAddProductForm = function() {
        productForm.classList.remove('hidden');
    }

    window.addProduct = function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const purchasePrice = document.getElementById('purchasePrice').value;
        const expirationDate = document.getElementById('expirationDate').value;
        const stock = document.getElementById('stock').value;
        const minStock = document.getElementById('minStock').value;

        const newProduct = {
            name,
            purchasePrice,
            expirationDate,
            stock,
            minStock
        };

        products.push(newProduct);
        renderProducts();
        productForm.classList.add('hidden');
    }

    window.removeProduct = function(index) {
        products.splice(index, 1);
        renderProducts();
    }

    window.editProduct = function(index) {
        // Adicionar funcionalidade de edição aqui
        alert('Funcionalidade de edição ainda não implementada.');
    }

    window.generateReport = function() {
        // Adicionar funcionalidade de geração de relatório aqui
        alert('Funcionalidade de geração de relatório ainda não implementada.');
    }

    // Inicializar a exibição
    showAllProducts();
});
